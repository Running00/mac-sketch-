//
//  SketchI18NPlugin.h
//  SketchI18NPlugin
//
//  Created by Li Guangming on 15/10/30.
//  Copyright © 2015年 Li Guangming. All rights reserved.
//

#import <Cocoa/Cocoa.h>

//! Project version number for SketchI18NPlugin.
FOUNDATION_EXPORT double SketchI18NPluginVersionNumber;

//! Project version string for SketchI18NPlugin.
FOUNDATION_EXPORT const unsigned char SketchI18NPluginVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <SketchI18NPlugin/PublicHeader.h>

#import "SketchI18NPluginManager.h"
